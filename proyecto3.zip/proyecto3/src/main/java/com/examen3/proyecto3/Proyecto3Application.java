package com.examen3.proyecto3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Proyecto3Application {

	public static void main(String[] args) {
		SpringApplication.run(Proyecto3Application.class, args);
	}

}
